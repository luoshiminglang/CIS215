//
//  ViewController.swift
//  Apple Pie5
//
//  Created by 123456 on 4/6/21.
//  Copyright © 2021 123456. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
//    var listOfWords = ["buccaneer","swift", "glorious", "incandescent", "bug", "program"]

    @IBOutlet var treeImagView: UIImageView!
    @IBOutlet var correctWordLabel: UILabel!
    @IBOutlet var scoreLabel: UILabel!
    @IBOutlet var letterButtons: [UIButton]!
    var listOfWords = ["buccaneer", "swift", "glorious", "incandescent", "bug", "program"]
    let incorrectMovesAllowed = 7
    var totalWins = 0 {
        didSet {
            newRound()
        }
    }
    var totalLosse = 0 {
        didSet {
            newRound()
        }
    }
    var currentGame: Game!
//load
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        newRound()
    }


    @IBAction func letterButtonPressed(_ sender: UIButton) {
        sender.isEnabled = false
        let letterString = sender.title(for: .normal)!
        let letter = Character(letterString.lowercased())
        currentGame.playerGuessed(letter: letter)
//        updateUI()
        updateGameState()
    }
    func newRound() {
        if !listOfWords.isEmpty {
        let newWord = listOfWords.removeFirst()
        print(newWord)
        print(listOfWords)
        currentGame = Game(word: newWord, incorrectMovesRemaining: incorrectMovesAllowed, guessedLetters: [])
            enableLetterButtons(true)
        updateUI()
        } else {
            enableLetterButtons(false)
        }
        
    }
    func enableLetterButtons(_ enable: Bool) {
        for button in letterButtons {
            button.isEnabled = enable
        }
    }
    func updateUI() {
        var letters = [String]()
        for letter in currentGame.formattedWord {
            letters.append(String(letter))
        }
    let wordWithSpacing = letters.joined(separator: " ")
                 correctWordLabel.text = wordWithSpacing
        
 //      currentGame.formattedWord
        scoreLabel.text = "Wins: \(totalWins), Losses:  \(totalLosse)"
        treeImagView.image = UIImage(named: "Tree \(currentGame.incorrectMovesRemaining)")
    }
    func updateGameState(){
        if currentGame.incorrectMovesRemaining == 0 {
            totalLosse += 1
        } else if currentGame.word == currentGame.formattedWord {
            totalWins += 1
        } else {
            updateUI()
        }
    }
}

