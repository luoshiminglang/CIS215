//
//  ViewController.swift
//  TwoButtons
//
//  Created by user182345 on 3/24/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var textField: UITextField!
    
    @IBOutlet var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func setTextButtonTapped(_ sender: UIButton) {
        let text = textField.text
        label.text = text
    }
    
    @IBAction func clearTextButtonTapped(_ sender: UIButton) {
        label.text = ""
    }
}

