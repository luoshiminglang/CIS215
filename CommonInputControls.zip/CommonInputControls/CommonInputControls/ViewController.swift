//
//  ViewController.swift
//  CommonInputControls
//
//  Created by user182345 on 3/13/21.
//  Copyright © 2021 user182345. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
@IBAction func buttonTaped(_ sender: Any) {
    print("Button was pressed")}
@IBAction        func swichToggled(_ sender: UISwitch)  {
        if sender.isOn {
            print("Switch is on!")
        } else {
            print("Switch is off")
        }
    }

}

